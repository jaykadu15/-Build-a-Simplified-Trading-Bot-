from bot.client import get_client

client = get_client()
balance = client.futures_account_balance()
print("✅ Testnet API works! Balance info:")
print(balance)
