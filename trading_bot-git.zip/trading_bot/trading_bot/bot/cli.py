import argparse
import logging
from bot.logging_config import setup_logger
from bot.client import get_client
from bot.orders import place_order
from bot.validators import validate_inputs

def main():
    setup_logger()  # 🔥 MUST be first

    parser = argparse.ArgumentParser(description="Binance Futures Trading Bot")
    parser.add_argument("--symbol", required=True)
    parser.add_argument("--side", required=True)
    parser.add_argument("--type", required=True)
    parser.add_argument("--quantity", type=float, required=True)
    parser.add_argument("--price", type=float)

    args = parser.parse_args()

    try:
        validate_inputs(
            args.symbol,
            args.side,
            args.type,
            args.quantity,
            args.price
        )

        client = get_client()

        order = place_order(
            client,
            args.symbol,
            args.side,
            args.type,
            args.quantity,
            args.price
        )

        print("\nOrder Successful")
        print(f"Order ID: {order.get('orderId')}")
        print(f"Status: {order.get('status')}")
        print(f"Executed Qty: {order.get('executedQty')}")
        print(f"Avg Price: {order.get('avgPrice')}")

        logging.info("CLI execution completed successfully")

    except Exception as e:
        logging.error(f"CLI Error: {e}")
        print(f"Error: {e}")

if __name__ == "__main__":
    main()
