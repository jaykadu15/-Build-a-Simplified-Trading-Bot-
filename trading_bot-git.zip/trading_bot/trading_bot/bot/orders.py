import logging

def place_order(client, symbol, side, order_type, quantity, price=None):
    params = {
        "symbol": symbol,
        "side": side.upper(),
        "type": order_type.upper(),
        "quantity": quantity
    }

    if order_type.upper() == "LIMIT":
        if price is None:
            logging.error("LIMIT order without price")
            raise ValueError("Price is required for LIMIT orders")

        params["price"] = price
        params["timeInForce"] = "GTC"

    logging.info(f"Placing order: {params}")

    try:
        order = client.futures_create_order(**params)
        logging.info(f"Order placed successfully: {order}")
        return order

    except Exception as e:
        logging.error(f"Error placing order: {e}")
        raise
