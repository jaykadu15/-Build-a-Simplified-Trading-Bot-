import os
import logging
from binance.client import Client
from dotenv import load_dotenv

def get_client():
    logging.info("Loading environment variables...")
    load_dotenv()

    api_key = os.getenv("BINANCE_API_KEY")
    api_secret = os.getenv("BINANCE_API_SECRET")

    if not api_key or not api_secret:
        logging.error("API key or secret not found in .env file")
        raise Exception("API key or secret not found in .env")

    logging.info("Creating Binance Futures Testnet client")
    
    client = Client(api_key, api_secret, testnet=True)
    return client
