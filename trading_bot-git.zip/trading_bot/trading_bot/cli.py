import argparse
import logging

from bot.client import get_client
from bot.logging_config import setup_logging
from bot.orders import place_order
from bot.validators import validate_args


def parse_args():
    parser = argparse.ArgumentParser(
        description="Binance Futures Testnet Trading Bot"
    )

    parser.add_argument("--symbol", required=True, help="Trading symbol (e.g. BTCUSDT)")
    parser.add_argument("--side", required=True, choices=["BUY", "SELL"], help="Order side")
    parser.add_argument(
        "--type", required=True, choices=["MARKET", "LIMIT"], help="Order type"
    )
    parser.add_argument("--quantity", required=True, type=float, help="Order quantity")
    parser.add_argument("--price", type=float, help="Price (required for LIMIT orders)")

    return parser.parse_args()


def main():
    setup_logging()
    print("CLI started")

    args = parse_args()

    try:
        validate_args(args)

        logging.info(
            f"Order Request | Symbol={args.symbol} Side={args.side} "
            f"Type={args.type} Qty={args.quantity} Price={args.price}"
        )

        client = get_client()

        order = place_order(
            client=client,
            symbol=args.symbol,
            side=args.side,
            order_type=args.type,
            quantity=args.quantity,
            price=args.price,
        )

        print("\n===== ORDER RESULT =====")
        print(f"Order ID     : {order.get('orderId')}")
        print(f"Status       : {order.get('status')}")
        print(f"Executed Qty : {order.get('executedQty')}")
        print(f"Avg Price    : {order.get('avgPrice', 'N/A')}")
        print("========================\n")

        logging.info(f"Order Success | ID={order.get('orderId')}")

    except Exception as e:
        logging.exception("Order failed")
        print(f"\nERROR: {e}\n")


if __name__ == "__main__":
    main()
